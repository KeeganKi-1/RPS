package actor;

/**
 *
 * @author spockm
 */
public interface BlockedLocation 
{
    
}
