package brain;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.function.Function;

import actor.BotBrain;
import actor.GameObject;
import actor.Rock;
import grid.Location;

public class DemoBot extends BotBrain{

    @Override
    
    public int chooseAction() {
        Location myLoc = new Location(getRow(), getCol());
        return myLoc.getDirectionToward(myLoc);
    }
    
}
