package brain;

import actor.BotBrain;

public class DemoBot extends BotBrain{

    @Override
    public int chooseAction() {
        // TODO Auto-generated method stub
        return 0;
    }
    
}
