package brain;

import actor.BotBrain;
import grid.Location;

public class RowClaimerBot extends BotBrain {
    //Direction for it to move
int direction = 90;
/*
Gets our location and the location of where we want to move next
If the place it wants to move is already inside one of the grid then it turns around
*/
    @Override
    public int chooseAction() {
    
    Location myLoc = new Location(getRow(), getCol());
    Location nextLoc = myLoc.getAdjacentLocation(direction);
    if(nextLoc.getCol()>16)
    direction = 270;
    else if(nextLoc.getCol()<7)
    direction = 90;
    
        return direction ;
    }
    
}
