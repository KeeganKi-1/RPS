package brain;

import actor.BotBrain;
import actor.GameObject;
import actor.Rock;
import grid.Location;

public class RockFinder extends BotBrain{
 int direction = 0;
    @Override
    /**
     * If there is a rock on the grid then it will move to it until it reaches its row 
     * and then will move to the column
     * When the rock is within a block of it it will mine the block
     * @return either the direction to move or to mine the rock
     */
    public int chooseAction() {
        Location rocLoc = findRocks();
        if(rocLoc != null){
        if(getRow()>rocLoc.getRow())
        direction = 0;
        else if(getRow()<rocLoc.getRow())
        direction = 180;
        else if(getCol()>rocLoc.getCol())
        direction = 270;
        else if(getCol()<rocLoc.getCol())
        direction = 90;
        }
        for(int dir=0; dir<360; dir+=45) //loop through the 8 directions
        {
            Location next = new Location(getRow(),getCol()).getAdjacentLocation(dir);
            if(next.isValidLocation() && getArena()[next.getRow()][next.getCol()] instanceof Rock)
                return MINE+dir;  
        }
        return direction;
    }
    /**
     * It loops through the entire grid from the up most left corner
     * and finds the location of the rock
     * 
     * @return the Location of the up left most rock in the grid if it exists
     */
    public Location findRocks(){
        GameObject[][] arena = getArena();
        for(int i =0; i<arena.length; i++){
            for(int j = 0; j<arena[0].length;j++){
                if(arena[i][j] instanceof Rock){
                   return new Location(i,j);
                }
            }


        }
        
        
        return null;
    }
}
