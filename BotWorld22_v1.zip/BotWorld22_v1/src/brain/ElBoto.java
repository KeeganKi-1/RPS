package brain;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.function.Function;

import actor.BotBrain;
import actor.GameObject;
import actor.Rock;
import grid.Location;

public class ElBoto extends BotBrain {
    boolean gotList = false;
    ArrayList<Location> locationsToGo;
    Location myLoc = new Location(getRow(), getCol());
    int index = -1;
    
    @Override
    public int chooseAction() {
        updateMyLoc();
if(!gotList){
    locationsToGo = getOrderedLocsForAStar(aStarSearch(myLoc, getClosestRock()));
    gotList=true;
}
index++;
//System.out.println(aStarSearch(myLoc, getClosestRock()).size());
return myLoc.getDirectionToward(locationsToGo.get(index));
        
        
    }
    /**
     * will be repeatedly called to update my location
     */
    public void updateMyLoc(){
        myLoc = new Location(getRow(), getCol());
    }
    public double getEstRockDist(Location locToCheck){
        Location rockLoc = getClosestRock();
        return Math.sqrt(((rockLoc.getRow()-locToCheck.getRow())*(rockLoc.getRow()-locToCheck.getRow()))+((rockLoc.getCol()-locToCheck.getCol())*(rockLoc.getCol()-locToCheck.getCol())));
    }
    public double getStartDist(Location locToCheck){
        
        return Math.sqrt(((myLoc.getRow()-locToCheck.getRow())*(myLoc.getRow()-locToCheck.getRow()))+((myLoc.getCol()-locToCheck.getCol())*(myLoc.getCol()-locToCheck.getCol())));
    }
    
    public class Node{
        Location loc;
        Node parent;
        double gScore;
        double hScore;
        double fScore;
        public Node(Location location){
            loc = location;
            fScore = getEstRockDist(location);
            gScore = getStartDist(location);
            hScore = fScore+gScore;
        }
        public void setParent(Node par){
            parent = par;
        }




    }

    Comparator<Node> nodeComparator = new Comparator<Node>(){
        @Override 
        public int compare(Node n1, Node n2){
            return (int) (n1.hScore-n2.hScore);
        }
    };

    public ArrayList<Location> getOrderedLocsForAStar(ArrayList<Node> closedSet){
        ArrayList<Location> orderedList = new ArrayList<Location>();
        Node current = closedSet.get(0);
        //System.out.println(closedSet.size());
        for(int i =0; i<closedSet.size(); i++){
            orderedList.add(0, current.loc);
            current = current.parent;
        }
        return orderedList;
    }

public ArrayList<Node> aStarSearch(Location start, Location goal){

    PriorityQueue<Node> openSet = new PriorityQueue<Node>(nodeComparator);
    ArrayList<Node> closedSet = new ArrayList<Node>();
    openSet.add(new Node(start));
    while(openSet.size() != 0 ){
        Node current = openSet.poll();
        closedSet.add(current);
        if(current.loc.getRow() == goal.getRow() &&current.loc.getRow() == goal.getRow()){
           
            return closedSet;
        }
    for(int i = 0; i<8; i++){
        Location adjacentLoc = current.loc.getAdjacentLocation(i*45);
        boolean inClosedLoop = false;
        Node adjacentNode = new Node(adjacentLoc);
        for(Node e : closedSet){
            if(e.loc.getCol() == adjacentLoc.getCol() && e.loc.getRow() == adjacentLoc.getRow())
            {inClosedLoop = true;}
        }
        // System.out.println(!((adjacentLoc.isValidLocation() && getArena()[adjacentLoc.getRow()][adjacentLoc.getCol()] == null) || inClosedLoop));
        if(!((adjacentLoc.isValidLocation() && getArena()[adjacentLoc.getRow()][adjacentLoc.getCol()] == null) || inClosedLoop)){
            // System.out.println(!openSet.contains(adjacentNode));
             System.out.println(adjacentNode.fScore+current.gScore<adjacentNode.hScore);
            if(!openSet.contains(adjacentNode) || adjacentNode.fScore+current.gScore<adjacentNode.hScore){
            adjacentNode.parent=current;
            System.out.println(adjacentNode.fScore+current.gScore);
            
            if(!openSet.contains(adjacentNode)){
                System.out.println("made It");
                openSet.add(adjacentNode);
            }
        }
        }
    }
    }
    return closedSet;
    // int indexF = 0;
    // ArrayList<Location> openSet = new ArrayList<Location>(); 
    // openSet.add(myLoc);
    // ArrayList<Location> cameFrom = new ArrayList<Location>();
    // ArrayList<Double> gScore = new ArrayList<Double>();
    // gScore.add(0.0);
    // ArrayList<Double> fScore = new ArrayList<Double>();
    // fScore.add(getEstRockDist(myLoc));
    // while(openSet.size() != 0){
    //     for(int i= 0; i<openSet.size(); i++){
    //         if(fScore.get(i)<fScore.get(indexF))
    //             indexF = i;
    //     }
    //     Location current = openSet.get(indexF);
    //     openSet.remove(indexF);
    //     for(int i =0; i<8; i++){
    //         Double tentative_gScore = gScore.get(indexF)+1;
    //         gScore.add(getEstRockDist(current.getAdjacentLocation(i*45)));
    //         if(gScore.get(indexF)<gScore.get(indexF+i));{
    //             cameFrom.add(current.getAdjacentLocation(i*45));
    //             gScore.add(tentative_gScore);
    //             fScore.add(tentative_gScore+getEstRockDist(current.getAdjacentLocation(i*45)));
    //         }
    //     }
    // }
    
}
    public int getToRock(Location rockLoc){
        GameObject[][] arena = getArena();
        int dirToRock = myLoc.getDirectionToward(rockLoc);
        
        return 0;
    }
    /**
     * 
     * Gets an arraylist of all the rocks
     * then goes through and checks which rock has the closest straight line distance
     * and stores it as closest loc
     * 
     * 
     * @return the location of the closest rock
     */
    public Location getClosestRock(){
        GameObject[][] arena = getArena();
        Location closestRoc = new Location(0,0);;
        double closestDistance = 1000;
        double nowDistance = 0;
        ArrayList<Location> rockLocs = new ArrayList<Location>();
        for(int i =0; i<arena.length; i++){
            for(int j = 0; j<arena[0].length;j++){
                if(arena[i][j] instanceof Rock){
                   rockLocs.add(new Location(i,j));
                }
            }
    
        }
        for(Location rockLoc : rockLocs){
            nowDistance = Math.sqrt(((rockLoc.getRow()-getRow())*(rockLoc.getRow()-getRow()))+((rockLoc.getCol()-getCol())*(rockLoc.getCol()-getCol())));
            if(nowDistance<closestDistance){
                closestDistance = nowDistance;
                closestRoc = rockLoc;
            }
        }
        return closestRoc;
    }

    
    
}
