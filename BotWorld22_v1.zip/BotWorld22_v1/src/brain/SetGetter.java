package brain;

import actor.BotBrain;
import actor.GameObject;
import actor.Paper;
import actor.Rock;
import actor.Scissors;
import grid.Location;

public class SetGetter extends BotBrain {

    int direction = 0;
    boolean scisCap = false;
    boolean papCap = false;
    boolean threeMove = false;
    int threeCount = 0;
    int round = 0;
    int lastRound = 0;
    int paperMoveDir = 0;
    @Override
    public int chooseAction() {
        if(getScore() == 131)
        return REST;
        
        Location rocLoc = findRocks();
        round = getRoundNumber();
        if(round>lastRound){
            lastRound=round;
            scisCap = false;
            papCap = false;
        }
        
        
            Location next1 = new Location(getRow(),getCol()).getAdjacentLocation(direction);
            if(next1.isValidLocation() && getArena()[next1.getRow()][next1.getCol()] instanceof Paper){
               paperMoveDir = direction + 90;
               if(paperMoveDir>270){
                   paperMoveDir = 0;
               }
               threeMove = true;
               System.out.println("paper");
            }
        
        if(threeMove){
            threeCount++;
            System.out.println("moving");
            if(threeCount == 3){
                threeCount = 0;
                threeMove = false;
            }
            return paperMoveDir;
        }
        if(rocLoc != null){
            
        if(getRow()>rocLoc.getRow())
        direction = 0;
        else if(getRow()<rocLoc.getRow())
        direction = 180;
        else if(getCol()>rocLoc.getCol())
        direction = 270;
        else if(getCol()<rocLoc.getCol())
        direction = 90;
        }
        else if(!papCap &&((getRow()>12 || getRow()<10)&&(getCol()>13 || getCol()<11))){
            
            
            Location myLoc = new Location(getRow(), getCol());
            direction = myLoc.getDirectionToward(new Location(11,12));
        }
        
         else if(!papCap && scisCap){
             papCap = true;
             return BID+1;
         }
        for(int dir=0; dir<360; dir+=45) //loop through the 8 directions
        {
            Location next = new Location(getRow(),getCol()).getAdjacentLocation(dir);
            if(next.isValidLocation() && getArena()[next.getRow()][next.getCol()] instanceof Rock)
                return MINE+dir;  
        }
        
            
        
        if(!scisCap){
           
        Location scissorsLoc = whereAreTheScissors();
        if(scissorsLoc == null) return REST; //No scissors, just rest.
        
        Location myLoc = new Location(getRow(), getCol());
        //Grab the scissors if they are close enough. (in a neighboring space)
        if(scissorsLoc.distanceTo(myLoc) < 2)
        {
            scisCap = true;
            return CAPTURE; //3000 
        }
        //Go toward the scissors if possible, or move randomly. 
        int dirTowardScissors = myLoc.getDirectionToward(scissorsLoc);
        Location next = myLoc.getAdjacentLocation(dirTowardScissors);
        
        if(next.isValidLocation() && getArena()[next.getRow()][next.getCol()] == null)
            return dirTowardScissors;
    }

        return direction;
        
    }
    /**
     * It loops through the entire grid from the up most left corner
     * and finds the location of the rock
     * 
     * @return the Location of the up left most rock in the grid if it exists
     */
    public Location findRocks(){
        GameObject[][] arena = getArena();
        for(int i =0; i<arena.length; i++){
            for(int j = 0; j<arena[0].length;j++){
                if(arena[i][j] instanceof Rock){
                   return new Location(i,j);
                }
            }


        }
        
        
        return null;
    }
    

    public Location whereAreTheScissors()
    {
        GameObject[][] theArena = getArena();
        for(int r=0; r<theArena.length; r++)
            for(int c=0; c<theArena[0].length; c++)
            {
                if(theArena[r][c] instanceof Scissors)
                    return new Location(r,c);
            }
        return null; //There are no scissors this turn. 
    }
}
