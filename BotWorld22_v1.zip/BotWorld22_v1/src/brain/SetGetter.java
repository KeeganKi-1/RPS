package brain;

import actor.BotBrain;
import actor.GameObject;
import actor.Paper;
import actor.Rock;
import actor.Scissors;
import grid.Location;

public class SetGetter extends BotBrain {

    int direction = 0;
    boolean scisCap = false;
    boolean papCap = false;
    
    @Override
    public int chooseAction() {
        Location rocLoc = findRocks();
        

        if(rocLoc != null){
        if(getRow()>rocLoc.getRow())
        direction = 0;
        else if(getRow()<rocLoc.getRow())
        direction = 180;
        else if(getCol()>rocLoc.getCol())
        direction = 270;
        else if(getCol()<rocLoc.getCol())
        direction = 90;
        }
        else if(!papCap){
            Location myLoc = new Location(getRow(), getCol());
            return myLoc.getDirectionToward(new Location(11,12));
        }
        
        // if(getScore()>0&& !papCap){
        //     return BID+1;
        // }
        for(int dir=0; dir<360; dir+=45) //loop through the 8 directions
        {
            Location next = new Location(getRow(),getCol()).getAdjacentLocation(dir);
            if(next.isValidLocation() && getArena()[next.getRow()][next.getCol()] instanceof Rock)
                return MINE+dir;  
        }
        for(int dir=0; dir<360; dir+=45) //loop through the 8 directions
        {
            Location next = new Location(getRow(),getCol()).getAdjacentLocation(dir);
            if(next.isValidLocation() && getArena()[next.getRow()][next.getCol()] instanceof Paper)
                return BID;  
        }
        if(!scisCap){
        Location scissorsLoc = whereAreTheScissors();
        if(scissorsLoc == null) return REST; //No scissors, just rest.
        
        Location myLoc = new Location(getRow(), getCol());
        //Grab the scissors if they are close enough. (in a neighboring space)
        if(scissorsLoc.distanceTo(myLoc) < 2)
        {
            scisCap = true;
            return CAPTURE; //3000 
        }
        //Go toward the scissors if possible, or move randomly. 
        int dirTowardScissors = myLoc.getDirectionToward(scissorsLoc);
        Location next = myLoc.getAdjacentLocation(dirTowardScissors);
        
        if(next.isValidLocation() && getArena()[next.getRow()][next.getCol()] == null)
            return dirTowardScissors;
    }

        return direction;
        
    }
    /**
     * It loops through the entire grid from the up most left corner
     * and finds the location of the rock
     * 
     * @return the Location of the up left most rock in the grid if it exists
     */
    public Location findRocks(){
        GameObject[][] arena = getArena();
        for(int i =0; i<arena.length; i++){
            for(int j = 0; j<arena[0].length;j++){
                if(arena[i][j] instanceof Rock){
                   return new Location(i,j);
                }
            }


        }
        
        
        return null;
    }
    /**
     * It loops through the entire grid from the up most left corner
     * and finds the location of the paper
     * 
     * @return the Location of the up left most paper in the grid if it exists
     */
    public Location findPaper(){
        GameObject[][] arena = getArena();
        for(int i =0; i<arena.length; i++){
            for(int j = 0; j<arena[0].length;j++){
                if(arena[i][j] instanceof Paper){
                   return new Location(i,j);
                }
            }


        }
        
        
        return null;
    }

    public Location whereAreTheScissors()
    {
        GameObject[][] theArena = getArena();
        for(int r=0; r<theArena.length; r++)
            for(int c=0; c<theArena[0].length; c++)
            {
                if(theArena[r][c] instanceof Scissors)
                    return new Location(r,c);
            }
        return null; //There are no scissors this turn. 
    }
}
